#!/bin/bash

FUNC_NAME=ft_name
FUNC_ARGS=""
FUNC_RETURN=void
FUNC_USE_ARGS=""
MAIN="int x = 41;"

source makeInit.bash $FUNC_NAME $FUNC_RETURN $FUNC_ARGS $FUNC_USE_ARGS $MAIN 0 0
make
./program > result.txt