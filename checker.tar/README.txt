	For makeInit: 
source makeInit.bash ft_abc int "int a" 'x' "int x = 41\;" 1 1

	