#include <stdio.h>

void ft_putchar (char arg) {
	putchar(arg);
}