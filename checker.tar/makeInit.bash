#!/bin/bash

[[ $# -ne 2 && $# -ne 4 && $# -ne 5 && $# -ne 6 && $# -ne 7 ]] && 
	echo "Usage: ft_function_name return_type [arg_type arg_param] [main vars] [ENABLE PRINT: 1] [ENABLE PRINT RETURN: 1]";

echo "arg number $#";

export NAME="$1";
export RETURN_TYPE="$2"; 

echo "$1 $2 $3 $4 $5";
if [ "$#" -eq 4 ]; then
	export ARG="$3";
	export VAL="$4";
fi

if [ "$#" -eq 5 ]; then
	export ARG="$3";
	export VAL="$4";
	export VAR="$5";
fi

if [ "$#" -eq 6 ]; then
	export ARG="$3";
	export VAL="$4";
	export VAR="$5";
	if [ "$6" -eq 1 ]; then
		export PRINT="-DMAIN_CAN_PRINT";
	else
		export PRINT="";
	fi
fi

if [ "$#" -eq 7 ]; then
	export ARG="$3";
	export VAL="$4";
	export VAR="$5";
	if [ "$6" -eq 1 ]; then
		export PRINT="-DMAIN_CAN_PRINT";
	fi
	if [ "$7" -eq 1 ]; then
		export RETURN="-DPRINT_RETURN";
	else
		export RETURN="";
	fi
fi

 