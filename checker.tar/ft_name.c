void	ft_putchar(char c);

void	ft_name()
{
	ft_putchar('E');
	ft_putchar('X');
	ft_putchar('A');
	ft_putchar('M');
	ft_putchar('P');
	ft_putchar('L');
	ft_putchar('E');
}
