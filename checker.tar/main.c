#define STR_VALUE(arg) #arg
#define STRING_FROM_DEFINE(name) STR_VALUE(name)

#ifdef MAIN_CAN_PRINT
	#include <stdio.h>
	#define PRINT_STRING(x) printf(x)
#else
	#define PRINT_STRING(x) ;
#endif

#ifdef RETURN_TYPE
	#define RETURN RETURN_TYPE
	#define RETURN_NAME STRING_FROM_DEFINE(RETURN_TYPE)
#else
	#define RETURN void
	#define RETURN_NAME "NO_TYPE"
#endif

#ifndef FUNCTION_ARG
	#define FUNCTION_ARG void
	#define FUNCTION_ARG_NAME "NO_ARGS"
	#define USE_ARG
	#define USE_ARG_NAME "NO_USE_ARGS"
#else
	#define FUNCTION_ARG_NAME STRING_FROM_DEFINE(FUNCTION_ARG)
#endif

#ifdef FUNCTION_NAME
	#ifdef FUNCTION_VALUE
		#define USE_ARG FUNCTION_VALUE
		#define USE_ARG_NAME STRING_FROM_DEFINE(USE_ARG)
	#endif
#endif

#ifndef FUNCTION_NAME
	#define FUNCTION_NAME emptyFunc; 
	#define USE_ARG 
	#define USE_ARG_NAME "NO_USE_ARGS"
	void emptyFunc() {
		PRINT_STRING("Empty function in main ...");
	}
#else
	RETURN FUNCTION_NAME(FUNCTION_ARG);
#endif

#ifdef MAIN_VAR
	#define MAIN_VAR_NAME STRING_FROM_DEFINE(MAIN_VAR)
#else
	#define MAIN_VAR_NAME "NO_MAIN_VARS"
#endif

#define FUNCTION_NAME_STRING STRING_FROM_DEFINE(FUNCTION_NAME)

#define V_DEBUG

int main(int argc, char const *argv[])
{
	#ifdef MAIN_VAR
		MAIN_VAR
	#endif

	#ifdef V_DEBUG
		printf("USE_ARG: %s; RETURN_TYPE: %s; FUNC_ARG: %s \n", USE_ARG_NAME, RETURN_NAME, FUNCTION_ARG_NAME);
		printf("FUNCTION_NAME: %s; MAIN_VAR: %s \n", FUNCTION_NAME_STRING, MAIN_VAR_NAME);
	
		printf("--------------------PROGRAM--------------------\n");
	#endif

	#ifdef FUNCTION_NAME
		#ifdef PRINT_RETURN
			#ifdef MAIN_CAN_PRINT
				printf("%d\n", FUNCTION_NAME(USE_ARG));
			#endif
		#else
			FUNCTION_NAME(USE_ARG);
		#endif
	#endif

	#ifdef V_DEBUG
		printf("$>\n------------------END PROGRAM------------------\n");
	#endif

	return 0;
}




/*
#include <>

int ft_putchar(char c) 
{
...
}

void ft_is_negative(int n) 
{
	if (n < 0) 
	{
		ft_putchar('N');
	}
	else
	{
		ft_putchar('P');
	}
}

int main() 
{
	ft_is_negative(18);
	return 0;
}
*/